package project2;

import java.util.Scanner;

public class UserInterfaceTest {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int Choice;
		boolean exit = false;

		while (!exit) {
			System.out.println("Welcome to Telecom Billing System!");
			System.out.println("Enter your choice:");
			System.out.println("1. View Call Details");
			System.out.println("2. Generate Invoice");
			System.out.println("3. Exit");
			Choice = scanner.nextInt();

			switch (Choice) {
			case 1:
				System.out.println("Displaying Call Details...");
				break;
			case 2:
				System.out.println("Generating voice...");
				break;
			case 3:
				exit = true;
				break;

			default:
				System.out.println("Invalid option..! please choose a valid option.");
			}
		}

		scanner.close();
	}

}
